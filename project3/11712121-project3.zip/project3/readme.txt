Note that tests in `sample` folder are for reference only.
The actual evaluation tests are in the `test` folder.
The `extra` gives you some tests for bonus features (array and struct).