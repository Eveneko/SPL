# SPL

## exit code

- syntax error, exit -1
- operator2str error, exit -2